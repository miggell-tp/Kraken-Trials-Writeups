Professor K. left behind this exported Chromium profile after a lecture.
Most activity is ordinary school work. Identify the one site that matters and
use the browser artifacts to recover the item the professor tried to remove.
